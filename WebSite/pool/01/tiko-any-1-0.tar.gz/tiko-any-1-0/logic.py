class Logic:
    def recv(self, ctx):
        ctx.log("got call")
